<footer>
<div class="footer">

    <p>DigiHawk &copy 2018 All rights reserved  </p>


</div>
</footer>
