@extends('layout.master')
@section('content')

    <h1 align="center"> You can find us at:</h1>
    <div class="pad-group">
    <div  id="map" style=" width:400px; height:400;">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d8866.843141339376!2d85.33644207751232!3d27.67202649811703!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xd7eb0581039e850d!2sDigiHawk+PVT.LTD!5e0!3m2!1sen!2snp!4v1515399428757" width="500" height="500" frameborder="0" style="border:1: padding-left:10px; "></iframe>
        </div>
            <div align="center">
            <li>CONTACT INFO</li>
            <li>Balkumari,Kathmandu</li>
            <li>Email: info@digihawk.net</li>
            <li>Website: http://digihawk.ga/</li>

            </div>
    </div>
    </h1>

    @endsection