<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Digihawk</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e((URL::asset('css/app.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e((URL::asset('css/myStyle.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e((URL::asset('css/menu.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e((URL::asset('css/footer.css'))); ?>"
    <link href="<?php echo e((URL::asset(URL::asset('js/menu.js')))); ?>}">
</head>
<body>

<div class="content">
    <div class="title" >
                                 DigiHawk
        <img src="Desktop/hawk.png" alt="Mountain View">
    </div>
    <div class="topnav" id="myTopnav">
        <a href="/welcome">Home</a>

        <a href="/contact">Contact</a>
        <a href="/about">About us</a>
        <input type="text" placeholder="Search..">
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">&#9776;</a>
    </div>
    <!--<div class="links">
        <a href="https://laravel.com/docs">Documentation</a>
        <a href="https://laracasts.com">Laracasts</a>
        <a href="https://laravel-news.com">News</a>
        <a href="https://forge.laravel.com">Forge</a>
        <a href="https://github.com/laravel/laravel">GitHub</a>
    </div>-->

</div>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>