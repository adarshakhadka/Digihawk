<html>
<title>
My app
</title>
<body>
<h1>This is awesome.</h1>
</body>
</html>