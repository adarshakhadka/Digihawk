<?php $__env->startSection('content'); ?>
<div align="center">
    <h1>Digihawk is an IT related company.</h1>

        <li>Members</li>
        <li>mark zuckerberg</li>
        <li>steve jobs</li>
        <li>john cena</li>
        <li>BATMAN</li>

ring us :987654321
address:balkumari



</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>